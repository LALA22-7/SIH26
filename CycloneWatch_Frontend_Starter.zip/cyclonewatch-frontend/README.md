# CycloneWatch — SIH 2026 PS70 Frontend

A ready-to-run React + Leaflet prototype for Kavya's Design + Frontend ownership.

## What is already implemented
- Day 1: design-token-based shell, Leaflet map, event selector, IR / Visible / Water Vapor layer controls.
- Day 2: cyclone centre marker, Level 1 status, Level 2 pattern + confidence card.
- Day 3: observed vs predicted track, provisional uncertainty corridor, T+12/T+24 prediction list.
- Day 4: T-48h → T0 historical replay slider, predicted vs actual comparison, Level 3 evidence drawer.
- Demo fixture data is clearly labelled as demo/prototype data.

## Run locally
1. Install Node.js 20+.
2. Open this folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local Vite URL shown in the terminal.

## Backend handoff
The frontend currently uses `src/data.js` as a fixture so you are not blocked by Backend/ML. Replace the fixture access with the team's stable endpoints when available:
- `POST /api/ps70/classify`
- `POST /api/ps70/predict`
- `GET /api/replay/{event_id}`
- `GET /api/metrics?event_id=...`

Do not change field names, timestamp conventions, or coordinate order silently. Project convention is UTC and GeoJSON coordinates are [longitude, latitude].

## Important scientific/demo rule
The master execution manual requires every displayed prediction to have source imagery, timestamp, and model/confidence metadata, and says demo placeholders must not be presented as real inference. Historical replay should ultimately work offline for the final demo.

## Day 5–8 focus
Day 5: fix mentor confusion only.
Day 6: visual polish + complete evidence panel + calibrated confidence presentation.
Day 7: freeze UI/features; only bug/visual/reliability fixes.
Day 8: live rehearsal with Backend, including an offline fallback.
