import React, {useMemo, useState} from 'react';
import {MapContainer, TileLayer, CircleMarker, Polyline, Polygon, useMap} from 'react-leaflet';
import {Activity, AlertTriangle, ChevronDown, Crosshair, Database, Layers3, LocateFixed, Menu, Radio, Satellite, ShieldCheck, SlidersHorizontal, X} from 'lucide-react';
import {EVENTS, REPLAY_STEPS, PREDICTION} from './data';

const TOKEN = {ir:'#f1c40f', visible:'#f5f5f5', wv:'#66b3ff'};

function FitMap({center}) { const map=useMap(); React.useEffect(()=>{map.setView(center,5.2)},[center,map]); return null; }

function MapView({event, layer, replayStep, showPrediction, onEvidence}) {
  const observed = replayStep ? [replayStep.actual, event.center] : [event.center];
  const predicted = replayStep ? [replayStep.predicted, ...PREDICTION.points.slice(1).map(p=>p.coords)] : PREDICTION.points.map(p=>p.coords);
  const current = replayStep ? replayStep.actual : event.center;
  const overlayLabel = layer==='ir'?'INFRARED':layer==='visible'?'VISIBLE':'WATER VAPOR';
  return <div className="map-wrap">
    <MapContainer center={event.center} zoom={5.2} zoomControl={false} className="map">
      <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <FitMap center={current}/>
      <Polyline positions={observed} pathOptions={{color:'#f6f7f9',weight:3,opacity:.9,dashArray:'5 6'}} />
      {showPrediction && <>
        <Polyline positions={predicted} pathOptions={{color:'#4da3ff',weight:4,opacity:.95}} />
        <Polygon positions={[[16.1,67.5],[16.5,68.1],[17.0,67.8],[17.2,67.1],[16.7,66.8]]} pathOptions={{color:'#4da3ff',weight:1,fillOpacity:.10,dashArray:'6 6'}} />
      </>}
      <CircleMarker center={current} radius={10} pathOptions={{color:'#fff',weight:3,fillColor:'#ff5a52',fillOpacity:.95}} eventHandlers={{click:onEvidence}} />
      {showPrediction && PREDICTION.points.slice(1).map((p,i)=><CircleMarker key={p.label} center={p.coords} radius={5} pathOptions={{color:'#4da3ff',weight:2,fillColor:'#0b1522',fillOpacity:1}} />)}
    </MapContainer>
    <div className="map-badge"><span className="live-dot"/> {overlayLabel} · DEMO FRAME</div>
    <div className="map-legend"><span><i className="legend-observed"/>Observed</span>{showPrediction&&<><span><i className="legend-predicted"/>Predicted</span><span><i className="legend-uncertainty"/>Uncertainty</span></>}</div>
  </div>
}

function LayerToggle({layer,setLayer}) { return <div className="layer-toggle"><div className="layer-title"><Layers3 size={15}/> SATELLITE LAYERS</div>{[['ir','Infrared'],['visible','Visible'],['wv','Water Vapor']].map(([id,label])=><button key={id} className={layer===id?'active':''} onClick={()=>setLayer(id)}><span className="layer-swatch" style={{background:TOKEN[id]}}/>{label}</button>)}</div> }

function StatusPanel({event,replayStep,showPrediction,setShowPrediction,onOpenEvidence}) { const data=replayStep||event; const confidence=replayStep?replayStep.confidence:event.confidence; return <aside className="side-panel">
  <section className="status-card"><div className="eyebrow"><span className="status-dot"/> LEVEL 1 · STATUS</div><div className="status-main">CYCLONE DETECTED</div><div className="status-sub"><span>Operational interpretation</span><span className="pill">Satellite-only</span></div></section>
  <section className="data-card"><div className="eyebrow">LEVEL 2 · CLASSIFICATION</div><div className="pattern-row"><div><div className="small-label">PATTERN TYPE</div><strong>{data.pattern}</strong></div><div className="confidence"><span>{Math.round(confidence*100)}%</span><small>confidence</small></div></div><div className="confidence-bar"><span style={{width:`${confidence*100}%`}}/></div><div className="coords"><div><small>CENTRE LAT</small><b>{(replayStep?replayStep.actual[0]:event.center[0]).toFixed(2)}°N</b></div><div><small>CENTRE LON</small><b>{(replayStep?replayStep.actual[1]:event.center[1]).toFixed(2)}°E</b></div></div></section>
  <section className="prediction-card"><div className="section-head"><div><div className="eyebrow">PREDICTION</div><strong>Future track</strong></div><button className={'switch '+(showPrediction?'on':'')} onClick={()=>setShowPrediction(v=>!v)}><span/></button></div><div className="forecast-list">{PREDICTION.points.slice(1).map(p=><button key={p.label} onClick={onOpenEvidence}><span>{p.label}</span><b>{p.pattern}</b><em>{Math.round(p.confidence*100)}%</em></button>)}</div><div className="provisional"><AlertTriangle size={13}/> Uncertainty corridor is provisional until calibration.</div></section>
 </aside> }

function Timeline({replayIndex,setReplayIndex}) { const step=REPLAY_STEPS[replayIndex]; return <section className="timeline-panel"><div className="timeline-head"><div><div className="eyebrow">HISTORICAL REPLAY</div><strong>What did the model know at this moment?</strong></div><div className="time-readout">{step.time}</div></div><div className="slider-wrap"><input type="range" min="0" max="4" step="1" value={replayIndex} onChange={e=>setReplayIndex(Number(e.target.value))}/><div className="ticks">{REPLAY_STEPS.map((s,i)=><button key={s.label} className={i===replayIndex?'selected':''} onClick={()=>setReplayIndex(i)}>{s.label}</button>)}</div></div><div className="replay-summary"><div><span>PREDICTED</span><b>{step.predicted[0].toFixed(2)}°N · {step.predicted[1].toFixed(2)}°E</b></div><div><span>ACTUAL</span><b>{step.actual[0].toFixed(2)}°N · {step.actual[1].toFixed(2)}°E</b></div><div><span>ERROR</span><b>{step.error} km</b></div><button onClick={()=>document.getElementById('evidence').scrollIntoView({behavior:'smooth'})}>Open evidence <ChevronDown size={15}/></button></div></section> }

function EvidencePanel({open,setOpen,event,replayStep}) { if(!open) return null; const time=replayStep?.time||'14 Jun 2023 · 12:00 UTC'; return <div className="evidence-overlay" onClick={()=>setOpen(false)}><section id="evidence" className="evidence-panel" onClick={e=>e.stopPropagation()}><div className="evidence-head"><div><div className="eyebrow">LEVEL 3 · EVIDENCE</div><h2>Why this decision?</h2></div><button onClick={()=>setOpen(false)}><X size={18}/></button></div><div className="evidence-image"><div className="scan-lines"/><Crosshair size={48}/><span>Source satellite frame</span></div><div className="evidence-grid"><div><small>SOURCE</small><b>INSAT / demo fixture</b></div><div><small>CHANNEL</small><b>Infrared</b></div><div><small>TIMESTAMP</small><b>{time}</b></div><div><small>CENTRE</small><b>{event.center[0].toFixed(2)}°N · {event.center[1].toFixed(2)}°E</b></div><div><small>PATTERN</small><b>{replayStep?.pattern||event.pattern}</b></div><div><small>MODEL</small><b>ps70-classifier · v0.2.0</b></div></div><div className="evidence-note"><ShieldCheck size={16}/><span>Demo values are fixtures until the Backend/ML response replaces them. Do not present them as measured live inference.</span></div></section></div> }

export default function App(){
 const [eventId,setEventId]=useState(EVENTS[0].id); const event=useMemo(()=>EVENTS.find(e=>e.id===eventId),[eventId]); const [layer,setLayer]=useState('ir'); const [replayIndex,setReplayIndex]=useState(4); const [showPrediction,setShowPrediction]=useState(true); const [evidence,setEvidence]=useState(false); const [mobileOpen,setMobileOpen]=useState(false); const replayStep=replayIndex===4?null:REPLAY_STEPS[replayIndex];
 return <div className="app"><header className="topbar"><div className="brand"><div className="brand-mark">+</div><div><strong>CycloneWatch</strong><span>PS70 · Decision Support</span></div></div><div className="top-controls"><label><span>EVENT</span><select value={eventId} onChange={e=>setEventId(e.target.value)}>{EVENTS.map(e=><option key={e.id} value={e.id}>{e.name} · {e.date}</option>)}</select></label><div className="system"><span className="live-dot"/> SYSTEM READY</div><button className="menu-btn" onClick={()=>setMobileOpen(v=>!v)}><Menu size={19}/></button></div></header>
 <main className="workspace"><section className="map-column"><div className="map-toolbar"><div><span className="eyebrow">OBSERVATION</span><h1>{event.name} <small>· {event.basin}</small></h1></div><div className="toolbar-meta"><span><Satellite size={14}/> {event.date}</span><span><Database size={14}/> DEMO DATA</span></div></div><MapView event={event} layer={layer} replayStep={replayStep} showPrediction={showPrediction} onEvidence={()=>setEvidence(true)}/><LayerToggle layer={layer} setLayer={setLayer}/></section><StatusPanel event={event} replayStep={replayStep} showPrediction={showPrediction} setShowPrediction={setShowPrediction} onOpenEvidence={()=>setEvidence(true)}/></main>
 <Timeline replayIndex={replayIndex} setReplayIndex={setReplayIndex}/>
 <footer className="footer"><span><Radio size={14}/> CycloneWatch · Prototype</span><span>OBSERVE → UNDERSTAND → PREDICT → UNCERTAINTY → EVIDENCE</span><span>Backend contract ready</span></footer>
 <EvidencePanel open={evidence} setOpen={setEvidence} event={event} replayStep={replayStep}/>
 </div>
}
