export const EVENTS = [
  { id:'biparjoy_2023', name:'Biparjoy', basin:'Arabian Sea', date:'14 Jun 2023', center:[15.2,68.4], pattern:'Curved Band', confidence:.72 },
  { id:'amphan_2020', name:'Amphan', basin:'Bay of Bengal', date:'18 May 2020', center:[16.8,87.2], pattern:'Eye / Eyewall', confidence:.84 }
];

export const REPLAY_STEPS = [
  { label:'T−48h', time:'12 Jun 2023 · 12:00 UTC', actual:[13.1,67.8], predicted:[13.4,67.2], error:68, pattern:'Banding', confidence:.61 },
  { label:'T−36h', time:'13 Jun 2023 · 00:00 UTC', actual:[13.8,68.1], predicted:[14.0,67.7], error:51, pattern:'Curved Band', confidence:.66 },
  { label:'T−24h', time:'13 Jun 2023 · 12:00 UTC', actual:[14.5,68.3], predicted:[14.7,68.0], error:42, pattern:'Curved Band', confidence:.69 },
  { label:'T−12h', time:'14 Jun 2023 · 00:00 UTC', actual:[14.9,68.4], predicted:[15.0,68.3], error:17, pattern:'Curved Band', confidence:.71 },
  { label:'T0', time:'14 Jun 2023 · 12:00 UTC', actual:[15.2,68.4], predicted:[15.2,68.4], error:0, pattern:'Curved Band', confidence:.72 }
];

export const PREDICTION = {
  baseTime:'14 Jun 2023 · 12:00 UTC',
  points:[
    {label:'Now', coords:[15.2,68.4], pattern:'Curved Band', confidence:.72},
    {label:'T+12h', coords:[16.1,67.8], pattern:'Eye', confidence:.64},
    {label:'T+24h', coords:[17.2,67.1], pattern:'Eye', confidence:.59}
  ],
  uncertainty:'Provisional'
};
