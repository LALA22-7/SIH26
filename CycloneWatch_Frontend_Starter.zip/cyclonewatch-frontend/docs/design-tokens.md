# CycloneWatch Design Tokens

## Visual direction
Scientific · clean · geospatial · operational · trustworthy.

Avoid neon cyberpunk, excessive cards, unnecessary animation, and generic AI imagery.

## Core tokens
- Background: #071019
- Panel: #0d1823
- Secondary panel: #101e2b
- Border: #243442
- Text: #e9f0f5
- Muted: #8799a8
- Prediction blue: #4da3ff
- Alert red: #ff5a52
- System green: #49d18b
- Radius: 12px

## Hierarchy
Level 1 = operational state.
Level 2 = classification / confidence / centre.
Level 3 = evidence and source metadata.

## Map semantics
Observed = white dashed line.
Predicted = blue solid line.
Uncertainty = blue dashed/transparent corridor.
