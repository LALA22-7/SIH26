# Frontend 8-Day Checklist

## Day 1 — Foundation
- [x] Tokens
- [x] React shell
- [x] Leaflet map
- [x] Event selector
- [x] IR / Visible / Water Vapor controls
- [ ] Connect deterministic backend satellite frame

## Day 2 — Classification
- [x] Centre marker
- [x] Level 1 status
- [x] Pattern card
- [x] Confidence
- [ ] Replace fixture with /api/ps70/classify

## Day 3 — Prediction
- [x] Observed track
- [x] Predicted T+12/T+24 track
- [x] Timeline/prediction list
- [x] Provisional uncertainty corridor
- [ ] Replace fixture with /api/ps70/predict

## Day 4 — Replay + Evidence
- [x] T-48h → T0 slider
- [x] Prediction vs actual
- [x] Error field
- [x] Level 3 evidence drawer
- [ ] Connect /api/replay/{event_id}

## Day 5 — Mentor fixes
Record exactly what confused the mentor and fix only those items.

## Day 6 — Polish
Spacing, typography, map controls, loading/error states, evidence panel, replay, confidence, responsive behavior.

## Day 7 — Freeze
No new features. Only bugs, visual corrections, and demo reliability.

## Day 8 — Rehearsal
Run the complete demo with Backend and confirm offline fallback.
